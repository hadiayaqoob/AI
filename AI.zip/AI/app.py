from flask import Flask, render_template, request, jsonify, redirect, url_for
import sqlite3
import os
from db import init_db, save_contact, get_contacts

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Initialize database
init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/contact', methods=['POST'])
def contact():
    try:
        data = request.json
        
        # Validate required fields
        if not data or not data.get('name') or not data.get('email'):
            return jsonify({'error': 'Name and email are required'}), 400
        
        # Save to database
        save_contact(
            name=data['name'],
            email=data['email'],
            subject=data.get('subject', ''),
            message=data.get('message', ''),
            subscribe=data.get('subscribe', False)
        )
        
        return jsonify({'success': True, 'message': 'Contact form submitted successfully!'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/admin/contacts')
def admin_contacts():
    """Admin view to see submitted contacts (optional)"""
    contacts = get_contacts()
    return render_template('admin.html', contacts=contacts)

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'ai-website'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
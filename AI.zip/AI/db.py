import sqlite3
import os
from datetime import datetime

def get_db_connection():
    """Create database connection"""
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize database and create tables if they don't exist"""
    conn = get_db_connection()
    
    # Create contacts table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            subject TEXT,
            message TEXT,
            subscribe BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create users table for future authentication
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()
    print("Database initialized successfully!")

def save_contact(name, email, subject='', message='', subscribe=False):
    """Save contact form data to database"""
    conn = get_db_connection()
    
    conn.execute('''
        INSERT INTO contacts (name, email, subject, message, subscribe)
        VALUES (?, ?, ?, ?, ?)
    ''', (name, email, subject, message, 1 if subscribe else 0))
    
    conn.commit()
    conn.close()
    return True

def get_contacts():
    """Retrieve all contacts from database"""
    conn = get_db_connection()
    contacts = conn.execute('SELECT * FROM contacts ORDER BY created_at DESC').fetchall()
    conn.close()
    return [dict(contact) for contact in contacts]

def get_contact_count():
    """Get total number of contacts"""
    conn = get_db_connection()
    count = conn.execute('SELECT COUNT(*) FROM contacts').fetchone()[0]
    conn.close()
    return count